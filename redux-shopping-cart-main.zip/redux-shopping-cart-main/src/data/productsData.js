const productsData = [
    {
        id: 1,
        img: "/images/prod1.png",
        rating: "★★★★★",
        title: "boAt Airdopes 131",
        price: 1099,
        quantity: 1,
    },
    {
        id: 2,
        img: "/images/prod2.png",
        rating: "★★★★",
        title: "boAt BassHeads 228",
        price: 649,
        quantity: 1,
    },
    {
        id: 3,
        img: "/images/prod3.png",
        rating: "★★★★★",
        title: "JBL Live 660NC",
        price: 9999,
        quantity: 1,
    },
    {
        id: 4,
        img: "/images/prod4.png",
        rating: "★★★★★",
        title: "boAt Rockerz 255",
        price: 899,
        quantity: 1,
    },
    {
        id: 5,
        img: "/images/prod5.png",
        rating: "★★★★",
        title: "JBL Endurance Run Sports",
        price: 999,
        quantity: 1,
    },
    {
        id: 6,
        img: "/images/prod6.png",
        rating: "★★★★",
        title: "JBL Tune 230NC TWS",
        price: 5999,
        quantity: 1,
    },
    {
        id: 7,
        img: "/images/prod7.png",
        rating: "★★★★★",
        title: "boAt Rockerz 410",
        price: 1599,
        quantity: 1,
    },
    {
        id: 8,
        img: "/images/prod8.png",
        rating: "★★★★",
        title: "JBL Live 200BT",
        price: 3699,
        quantity: 1,
    }
];

export default productsData;