# Card Memory Game

 <img src="/banner.gif" width="80%" />

## run

``` 
cd card-memory-game
npm install
npm start
```
---
*powered by React*