const productsData = [
    {
        id: 1,
        img: "/images/prod1.png",
        rating: "★★★★",
        title: "Hero GoPro 10",
        price: 54500,
        quantity: 1,
    },
    {
        id: 2,
        img: "/images/prod2.png",
        rating: "★★★★★",
        title: "Canon 1500D",
        price: 31000,
        quantity: 1,
    },
    {
        id: 3,
        img: "/images/prod3.png",
        rating: "★★★★",
        title: "Nikon Z 50",
        price: 84007,
        quantity: 1,
    },
    {
        id: 4,
        img: "/images/prod4.png",
        rating: "★★★★★",
        title: "Sony RX100",
        price: 53570,
        quantity: 1,
    },
    {
        id: 5,
        img: "/images/prod5.png",
        rating: "★★★★",
        title: "Sony Lens",
        price: 147990,
        quantity: 1,
    },
    {
        id: 6,
        img: "/images/prod6.png",
        rating: "★★★★★",
        title: "Hero GoPro 9",
        price: 54500,
        quantity: 1,
    },
    {
        id: 7,
        img: "/images/prod7.png",
        rating: "★★★★",
        title: "Canon Flash",
        price: 24990,
        quantity: 1,
    },
    {
        id: 8,
        img: "/images/prod8.png",
        rating: "★★★★",
        title: "Canon EOS",
        price: 54500,
        quantity: 1,
    }
];

export default productsData;